package model; /**
 * 
 */

import helper.BoundingBox;

import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * @author Cam
 *
 */

public class Gcode {
	
	String fileFormat;
	
	String filename;
	String programComment;
	
	String header;
	String footer;

	BoundingBox boundingBox;

	ArrayList<Operation> operations =new ArrayList<Operation>();
	ArrayList<Tool> tools;
	
	String gcode_complete;

	void parseGcode() {
		
		Pattern p = Pattern.compile("\\n[\\n]+");
		//String[] sectionsStrings = 	p.split(gcode_complete);	
		
		//TODO: spit at new line
		String[] sectionsStrings = 	gcode_complete.split("\\n\\n");

		int sections = sectionsStrings.length-1;
		
		String header = sectionsStrings[0];
		String footer = sectionsStrings[sections];
		
		parseHeader(header);
		
		for(int i =1;i<sections;i++) {
			parseOperation(sectionsStrings[i]);
		}
		//System.out.println(header);
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	public ArrayList<Tool> getTools() {
		return tools;
	}

	public void setTools(ArrayList<Tool> tools) {
		this.tools = tools;
	}

	private void parseHeader(String header) {
		// TODO Auto-generated method stub
		
		String[] comments = header.split("\\n");
		setProgramComment(comments[0]);
		
		for(int i=2; i<comments.length; i++) {
			
			//TODO populate tool list
			if(comments[i].contains("T")){
			Tool tool = new Tool(comments[i]);
			//System.out.println(i);
			}
		}
	}

	public void buildBoundingBox() {

		ArrayList<BoundingBox> operationBoxes = new ArrayList<BoundingBox>();
		for (Operation operation : operations){
			operationBoxes.add(operation.getBoundingBox());
		}
		this.boundingBox = new BoundingBox(operationBoxes);
	}

	/**
	 * @return the programComment
	 */
	public String getProgramComment() {
		return programComment;
	}

	/**
	 * @param programComment the programComment to set
	 */
	public void setProgramComment(String programComment) {
		this.programComment = programComment;
	}



	private void parseOperation(String string) {
		// TODO Auto-generated method stub
		Operation operation = new Operation(string);
		operations.add(operation);
	}



	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return the operations
	 */
	public ArrayList<Operation> getOperations() {
		return operations;
	}

	/**
	 * @param operations the operations to set
	 */
	public void setOperations(ArrayList<Operation> operations) {
		this.operations = operations;
	}

	/**
	 * @return the gcode_complete
	 */
	public String getGcode_complete() {
		updateGcode();

		return gcode_complete;
	}

	private void updateGcode() {

		String updatedGcode = this.header;

		for(Operation operation : operations){
			updatedGcode += operation.getGcodeOperation();
		}

		updatedGcode += this.footer;

		setGcode_complete(updatedGcode);

	}

	/**
	 * @param gcode_complete the gcode_complete to set
	 */
	public void setGcode_complete(String gcode_complete) {
		this.gcode_complete = gcode_complete;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public BoundingBox getBoundingBox() {
		return boundingBox;
	}

	public void setBoundingBox(BoundingBox boundingBox) {
		this.boundingBox = boundingBox;
	}

	/**
	 * @param filename
	 * @param gcode_complete
	 */
	public Gcode(String filename, String gcode_complete) {
		
		//System.out.println(filename);
		fileFormat = filename.substring(filename.lastIndexOf('.'));
		this.filename = filename;
		this.gcode_complete = gcode_complete;
		
		parseGcode();

		buildBoundingBox();
	}

	public Gcode() {
		// TODO Auto-generated constructor stub
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "gcode [filename=" + filename + ", gcode_complete=" + gcode_complete + "]";
	}



	public void setOperations(Operation operation) {
		// TODO Auto-generated method stub
		operations.clear();
		operations.add(operation);
	}



	public String getFileFormat() {
		// TODO Auto-generated method stub
		return fileFormat;
	}


	public void offset(float offsetX, int offsetY) {
		for (Operation operation : this.getOperations())
			operation.offset(offsetX, offsetY);
	}

	public void addOperations(ArrayList<Operation> operations) {
		this.operations.addAll(operations);

	}
}
