package helper;

import model.Gcode;
import model.Operation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Session {

    public static ArrayList<String> inputFiles = new ArrayList();
    public static ArrayList<Gcode> inputGcodes = new ArrayList<Gcode>();

    public static ArrayList<Gcode> outputGcodes = new ArrayList<Gcode>();

    public static Boolean splitFileMode = null;
    public static Boolean multipleJobs = null;
    public static Boolean arrayMode = null;

    public static boolean split() {
        for(Gcode gcode: inputGcodes){
            for (Operation operation : gcode.getOperations()) {
                Gcode outputGcode = new Gcode();

                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH_mm_ss");
                Date date = new Date();
                //System.out.println(dateFormat.format(date));

                //TODO add gcode format
                outputGcode.setFilename(gcode.getFilename() +
                        " - " + dateFormat.format(date) +
                        " - " + operation.getOperationName() +
                        gcode.getFileFormat());
                outputGcode.setHeader(gcode.getHeader());
                outputGcode.setFooter(gcode.getFooter());
                outputGcode.setOperations(operation);

                outputGcodes.add(outputGcode);
            }
        }
        return true;
    }

    public static boolean array(Gcode code, ArrayPattern arrayPattern) {

        float xLen = code.getBoundingBox().getXDim() + arrayPattern.getxKerf();
        float yLen = code.getBoundingBox().getYDim() + arrayPattern.getxKerf();

        ArrayList<Operation> arrayedOpperations = new ArrayList<Operation>();

        for (Operation operation : code.getOperations()) {
            for (int i = 0; i < arrayPattern.getxNum(); i++) {
                for (int j = 0; j < arrayPattern.getyNum(); j++) {
                    if (i != 0 && j != 0) {
                        arrayedOpperations.add(new Operation(operation).offset(xLen * i, yLen * j));
                    }else
                    arrayedOpperations.add(operation);
                }
            }

            code.setOperations(arrayedOpperations);


        }
        return true;
    }

    public static boolean readin(String s) {

        //String input_filename = "2018-01-26 earmuffs.tap";
        //String output_filename = args[1];
        InputStream inputFileStream = null;
        //FileOutputStream outputFileStream = null;

        Gcode inputGcode =null;
        String filereadString = null;

        try {

            //URL resource = Session.class.getResource(input_filename)
            //ClassLoader classLoader = Session.class.getClassLoader();
            //inputFileStream = new FileInputStream(classLoader.getResource(input_filename).getFile());

            ClassLoader classloader = Thread.currentThread().getContextClassLoader();
            InputStream is = classloader.getResourceAsStream(s);


            //inputFileStream = Session.class.getResourceAsStream(input_filename);
            //inputFileStream = new FileInputStream(input_filename);

            StringBuilder out = new StringBuilder();

            int c;
            while ((c = is.read()) != -1) {

                BufferedReader reader = new BufferedReader(new InputStreamReader(is));

                String line;
                while ((line = reader.readLine()) != null) {
                    out.append(line);
                    out.append('\n');
                }
            }

            inputGcodes.add(new Gcode(s, out.toString()));

            return false;
        } catch (
                IOException e) {
            e.printStackTrace();

        } finally {
            try {
                if (inputFileStream != null) {
                    inputFileStream.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static boolean writeOut() {

        Gcode outputGcode = new Gcode();

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH_mm_ss");
        Date date = new Date();
        //System.out.println(dateFormat.format(date));

        //TODO add gcode format
        /*
        outputGcode.setFilename(inputGcode.getFilename() + " - " + dateFormat.format(date) + " - " + operation.getOperationName() + inputGcode.getFileFormat());
        outputGcode.setHeader(inputGcode.getHeader());
        outputGcode.setFooter(inputGcode.getFooter());
        outputGcode.setOperations(operation);
        */

        //BufferedWriter writer = new BufferedWriter(new FileWriter(outputGcode.getFilename()));
        //System.out.println(outputGcode.toString());
        //writer.write(outputGcode.toString());
        //writer.close();

        return true;

    }

    public static void combineGcode(ArrayList<Gcode> gcodes){

        Gcode code = new Gcode();
        float offsetX = 0;

        for(Gcode gcode: gcodes) {

            gcode.offset(offsetX, 0);

            offsetX = gcode.getBoundingBox().getXDim()+10;

            code.addOperations(gcode.getOperations());
        }

        //code.getOperations().sort();


    }
}




