package helper; /**
 * 
 */

import java.awt.List;
import java.util.ArrayList;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Cam
 *
 */
public class Helper {
	
	public static String findWordfromCharinGcode(char searchChar, String gcode) {
		int position = gcode.indexOf(searchChar);
		String wordString = null;
		
		if(position>0 && Character.isDigit(gcode.charAt(position+1))) {
			
			wordString = gcode.substring(position,position+4);
			//System.out.println(wordString);
			wordString = wordString.split(" ")[0];
			//System.out.println(wordString);
					
			
			if(Character.isDigit(wordString.charAt(wordString.length()-1))){
				//System.out.println(wordString);
			
				return wordString;
			}else {
				return "T1";
			}
				
		}
		return "T1";
	}

	public static String findFirstWordPrefixInGcode(String searchString, String gcode) {

		String xWordpatternString = "\\b" + searchString +"\\S*";

		ArrayList<String> allMatches = new ArrayList<String>();
		ArrayList<Float> allMatchesNumber = new ArrayList<Float>();
		Matcher m = Pattern.compile(xWordpatternString)
				.matcher(gcode);
		while (m.find()) {
			allMatches.add(m.group());
		}
		//System.out.println(allMatchesNumber);

		return allMatches.get(0);
	}

	//TODO find all words that start with 'X'
	public static ArrayList<String> getAllWordsFromGcode(char searchChar, String gcode) {	

	String xWordpatternString = "\\b" + searchChar +"\\S*";
	
	ArrayList<String> allMatches = new ArrayList<String>();
	ArrayList<Float> allMatchesNumber = new ArrayList<Float>();
	 Matcher m = Pattern.compile(xWordpatternString)
	     .matcher(gcode);
	 while (m.find()) {
	   allMatches.add(m.group());
	   allMatchesNumber.add(Float.parseFloat(m.group().substring(1)));
	   
	 }
	 //System.out.println(allMatchesNumber);
	
	
	return allMatches;
	}


	public static String offsetWordsGcode(char searchChar, String gcode, float offset) {

		String xWordpatternString = "\\b" + searchChar +"\\S*";

		String out;

		ArrayList<String> allMatches = new ArrayList<String>();
		ArrayList<Float> allMatchesNumber = new ArrayList<Float>();
		Matcher m = Pattern.compile(xWordpatternString)
				.matcher(gcode);

		StringBuilder stringBuilder = new StringBuilder();

		int previousIndexEnd = 0;

		while (m.find()) {

			m.group();
			float currentX = Float.parseFloat(m.group().substring(1))+offset;

			System.out.println(currentX);

			int len = m.group().length();

			stringBuilder.append(gcode.substring(previousIndexEnd, m.start()));
			previousIndexEnd = m.start()+len-1;
			stringBuilder.append(Character.toString(searchChar) + (Float.parseFloat(m.group().substring(1))+offset));
			System.out.println();
			//m.replaceFirst("d" + Float.parseFloat(m.group().substring(1))+offset);
			//out = m.replaceFirst("X" + Float.parseFloat(m.group().substring(1))+offset);
			//System.out.print(out);
			//allMatches.add(m.group());
			//allMatchesNumber.add(Float.parseFloat(m.group().substring(1)));

		}

		return stringBuilder.toString();
	}
	
	
	public static ArrayList<Float> getAllCoordValuesFromGcode(char searchChar, String gcode) {	

		
	String xWordpatternString = "\\b" + searchChar +"\\S*";
	
	ArrayList<Float> allMatchesNumber = new ArrayList<Float>();
	 Matcher m = Pattern.compile(xWordpatternString)
	     .matcher(gcode);
	 while (m.find()) {
	   allMatchesNumber.add(Float.parseFloat(m.group().substring(1)));
	   
	 }
	 //System.out.println(allMatchesNumber);
	
	
	return allMatchesNumber;
	}
	
	public static float getMinValue(ArrayList<Float> values) {		
		Float minValue = null;	
		for(Float value: values) {
			if(minValue==null) {
				minValue = value;
			}else if(value<minValue){
				minValue = value;
			}	
		}
		return (float)minValue; 
	}
	
	public static float getMaxValue(ArrayList<Float> values) {		
		Float maxValue = null;	
		for(Float value: values) {
			if(maxValue==null) {
				maxValue = value;
			}else if(value>maxValue){
				maxValue = value;
			}	
		}
		return (float)maxValue; 
	}
	
	
}
