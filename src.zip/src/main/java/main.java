import helper.ArrayPattern;
import helper.Helper;
import helper.Session;
import model.Gcode;
import model.Operation;
import model.WorkOffset;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


//TODO - read in multiple gcode files.
//TODO - Add offset declarations to header.
//TODO - match tool operations.


public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Session.readin("square.nc");


		//System.out.println(Session.inputGcodes.get(0).getOperations().get(0).getBoundingBox());
		//System.out.println(Session.inputGcodes.get(0).getOperations().get(1).getBoundingBox());
		//System.out.println(Session.inputGcodes.get(0).getOperations().get(2).getBoundingBox());
		//System.out.print(Session.inputGcodes.get(0).getOperations().get(0).offset(10,0));

		//System.out.println(Session.inputGcodes.get(0).getBoundingBox());

		ArrayPattern arrayPattern = new ArrayPattern(2,2,10,100,100);

		Session.array(Session.inputGcodes.get(0),arrayPattern);

		System.out.println(Session.inputGcodes.get(0).getOperations().size());
		System.out.println(Session.inputGcodes.get(0).getGcode_complete());
	}
}
